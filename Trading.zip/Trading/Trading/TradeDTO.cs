﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Trading
{
    public class TradeDTO
    {
        public Int16 Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Style { get; set; }
        public string CP { get; set; }
        public string Expiry { get; set; }
        public Int16 StrikePrice { get; set; }
        public string CCY { get; set; }
    }
}
