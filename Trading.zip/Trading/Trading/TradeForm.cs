﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Trading
{
    public partial class TradeForm : Form
    {
        IList<TradeDTO> list;
        public TradeForm()
        {
            InitializeComponent();
        }

       

        private void btnFetch_Click(object sender, EventArgs e)
        {
            FileObjCreator fc = new FileObjCreator();
            ParserObjCreator pc = new ParserObjCreator();
            IDataParser Idp;
            if (label1.Text != "")
            {
                IDataProvider cc = fc.FileCreator(label1.Text);
                DataProcessor dp = new DataProcessor();
                Idp = pc.parserCreator(label1.Text);
                 list = dp.Process(cc, Idp);
                TradeGridView.DataSource = list;
            }
            else
            { MessageBox.Show("Please select proper CSV or XML file to process", "Information", MessageBoxButtons.OK); }
        }

       
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtTradeName.Text))
            {
                //Currently data is getting filtered on the name from the list and taking first record to do calculation.
                // if the datewise data needs to be filtered then can add one more condition in where clause to compare input date to list Expiry feild.
                IList<TradeDTO> stockList = (from stklst in list
                                             where stklst.Name == txtTradeName.Text 
                                             select stklst).ToList();
                
                int spotprice = String.IsNullOrEmpty(txtSpotPrice.Text) ? 1 : Convert.ToInt16(txtSpotPrice.Text);
                double volatility = String.IsNullOrEmpty(txtVolatility.Text) ? 1 : Convert.ToDouble(txtVolatility.Text)/100;
                double riskRate = String.IsNullOrEmpty(txtRiskFreeRate.Text) ? 1 : Convert.ToDouble(txtRiskFreeRate.Text)/100;
                
                BinomialCalculation binomialcalc;
                double presentValue=1;
                double agrregatedValue = 0;
                for(int j=0; j<stockList.Count(); j++)
                {
                    ;
                    DateTime date1 = Convert.ToDateTime(stockList[j].Expiry.Replace('.', '/'));
                    DateTime correctDatestr = Convert.ToDateTime(date1.Day.ToString() + '/' + date1.Month.ToString() + '/' + date1.Year.ToString());
                    DateTime date2=Convert.ToDateTime(dateTimePicker1.Text);
                    double timestep = Convert.ToDouble((correctDatestr - date2).TotalHours);

                    binomialcalc = new BinomialCalculation(spotprice, stockList[j].StrikePrice, timestep, volatility, riskRate, EPutCall.Call, 1);
                    presentValue = Convert.ToDouble(binomialcalc.OptionValue());
                    if(j==0) 
                     txtCalculatedPrice.Text = presentValue.ToString() + ' ' + stockList[j].CCY;
                     agrregatedValue = agrregatedValue + presentValue;
                }

                txtAgreegate.Text = agrregatedValue.ToString();
                if (stockList[0].CCY=="PLN")
                {
                    txtZAR.Text = (presentValue * Convert.ToDouble(3.66)).ToString();
                    txtCHF.Text = (presentValue * Convert.ToDouble(0.27)).ToString();

                }
                else if (stockList[0].CCY=="USD")
                {
                    txtZAR.Text = (presentValue * Convert.ToDouble(13.06)).ToString();
                    txtCHF.Text = (presentValue * Convert.ToDouble(0.95)).ToString();

                }

            }
            else { MessageBox.Show("Please Enter Trade Name"); }

        }


        private void btnReadFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "CSV files (*.csv)|*.csv|XML files (*.xml)|*.xml";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label1.Text = openFileDialog1.FileName;
            }
        }
    }
}
