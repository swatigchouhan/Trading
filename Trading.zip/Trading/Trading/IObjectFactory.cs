﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Trading
{
    public interface IObject {
    
    }
        public interface IObjectFactory:IDataProvider
        {

            IObject CreateInstance(string description);
        }

        public class clsObjectFactory: IObjectFactory
        {

            IObject IObjectFactory.CreateInstance(string fileName)
            {
                
               string extension = Path.GetExtension(fileName);
               Type t ; 
               if (extension == "csv" || extension== "CSV")
               {
                t = typeof(Trading.CSVContactDataProvider);    
               }
               else
               {
                t = typeof(Trading.XMLTradeDataProvider);    

               }
                string [] args= {fileName};
                return Activator.CreateInstance(t,args[0].ToString()) as IObject;
            }

            string IDataProvider.Read()
            {
                throw new NotImplementedException();
            }
        }
   
}
