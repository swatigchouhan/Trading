﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Trading
{
    public abstract class  ParserCreator
    {
       
            public abstract IDataParser parserCreator(string filename);

    }

        public class ParserObjCreator : ParserCreator
        {

            public override IDataParser parserCreator(string filename)
            {
                string extension = Path.GetExtension(filename);
                if (extension == ".csv" || extension == ".CSV")
                {
                    return new CSVContactParser();
                }
                else
                {
                    return new XMLTradeParser();
                }
            }

           
        }

    }

