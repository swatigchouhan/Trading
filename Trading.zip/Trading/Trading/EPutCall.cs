﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Trading
{
    // An option is a Put or Call
    public enum EPutCall
    {
        Call = 0,
        Put = 1
    }

}
