﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Trading
{
    public class DataProcessor
    {
        public IList<TradeDTO> Process(IDataProvider cdp, IDataParser cp)
        {
            string providedData = cdp.Read();
            IList<TradeDTO> parsedData = cp.Parse(providedData);
            //cw.Write(parsedData);
            return parsedData;
        }
    }
    public class CSVContactDataProvider : IDataProvider
    {
        private readonly string _filename;

        public CSVContactDataProvider(string filename)
        {
            _filename = filename;
        }

        public string Read()
        {
            TextReader tr = new StreamReader(_filename);
           string str= tr.ReadToEnd();
            tr.Close();
            return str;
        }
    }

    public class CSVContactParser : IDataParser
    {
        public IList<TradeDTO> Parse(string csvData)
        {
            IList<TradeDTO> trades = new List<TradeDTO>();
            csvData= csvData.Replace("\r\n","\\r\\n");
            string[] lines = csvData.Split(new string[] { "\\r\\n".Trim() }, StringSplitOptions.None);
            //lines.Skip(0);
            var result = lines.Skip(1);
            foreach (string line in result)
            {
               
                string[] columns = line.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                var contact = new TradeDTO
                {
                    Id = Convert.ToInt16(columns[0]),
                    Name = columns[1],
                    Type = columns[2],
                    Style=columns[3],
                    CP=columns[4],
                    Expiry= columns[5],
                    StrikePrice= Convert.ToInt16(columns[6]),
                    CCY= columns[7]

                };
                trades.Add(contact);
            }

            return trades;
        }
    }

    public class XMLTradeDataProvider : IDataProvider
    {
        private readonly string _filename;

        public XMLTradeDataProvider(string filename)
        {
            _filename = filename;
        }

        public string Read()
        {

           return System.IO.File.ReadAllText(_filename);
        }
    }

    public class XMLTradeParser : IDataParser
    {

        IList<TradeDTO> IDataParser.Parse(string tradeList)
        {
            IList<TradeDTO> trades = new List<TradeDTO>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(tradeList);
            string xpath = "portfolio/trade";
            var nodes = xmlDoc.SelectNodes(xpath);
            foreach (XmlNode childrenNode in nodes)
            {
                TradeDTO tradeDto = new TradeDTO();

              tradeDto.Id = Convert.ToInt16(childrenNode.Attributes["id"].Value);
              tradeDto.Name = childrenNode.Attributes["name"].Value;
              tradeDto.Type = childrenNode.Attributes["type"].Value;
              tradeDto.Style = childrenNode.Attributes["style"].Value;
              tradeDto.CP = childrenNode.Attributes["cp"].Value;
              tradeDto.Expiry = childrenNode.Attributes["expiry"].Value;
              tradeDto.StrikePrice = Convert.ToInt16(childrenNode.Attributes["strike"].Value);
              tradeDto.CCY = childrenNode.Attributes["ccy"].Value;
              trades.Add(tradeDto);
            } 
            return trades;
        }
    }

    public abstract class ObjectCreate
    { 
    public abstract IDataProvider FileCreator(string filename);

    }

    public class FileObjCreator: ObjectCreate
    {

        public override IDataProvider FileCreator(string filename)
        {
            string extension = Path.GetExtension(filename);
               if (extension == ".csv" || extension == ".CSV")
               {
                   return new CSVContactDataProvider(filename);
               }
               else
               {
                   return new XMLTradeDataProvider(filename);
               }
        }
    }
}
