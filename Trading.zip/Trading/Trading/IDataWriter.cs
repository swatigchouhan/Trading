﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Trading
{
    public interface IDataWriter
    {
        void Write(IList<TradeDTO> contactData);
    }
}
