﻿namespace Trading
{
    partial class TradeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnFetch;
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnReadFile = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TradeGridView = new System.Windows.Forms.DataGridView();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSpotPrice = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.txtTradeName = new System.Windows.Forms.TextBox();
            this.txtSpotPrice = new System.Windows.Forms.TextBox();
            this.txtVolatility = new System.Windows.Forms.TextBox();
            this.txtRiskFreeRate = new System.Windows.Forms.TextBox();
            this.lblVoltality = new System.Windows.Forms.Label();
            this.lblRiskFreeRate = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCalculatedPrice = new System.Windows.Forms.TextBox();
            this.txtZAR = new System.Windows.Forms.TextBox();
            this.txtCHF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAgreegate = new System.Windows.Forms.TextBox();
            btnFetch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TradeGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnFetch
            // 
            btnFetch.Location = new System.Drawing.Point(425, 45);
            btnFetch.Name = "btnFetch";
            btnFetch.Size = new System.Drawing.Size(75, 23);
            btnFetch.TabIndex = 3;
            btnFetch.Text = "Fetch ";
            btnFetch.UseVisualStyleBackColor = true;
            btnFetch.Click += new System.EventHandler(this.btnFetch_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnReadFile
            // 
            this.btnReadFile.Location = new System.Drawing.Point(320, 45);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(75, 23);
            this.btnReadFile.TabIndex = 0;
            this.btnReadFile.Text = "Read File";
            this.btnReadFile.UseVisualStyleBackColor = true;
            this.btnReadFile.Click += new System.EventHandler(this.btnReadFile_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // TradeGridView
            // 
            this.TradeGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TradeGridView.Location = new System.Drawing.Point(30, 99);
            this.TradeGridView.Name = "TradeGridView";
            this.TradeGridView.Size = new System.Drawing.Size(847, 150);
            this.TradeGridView.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(27, 273);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(66, 13);
            this.lblName.TabIndex = 4;
            this.lblName.Text = "Trade Name";
            // 
            // lblSpotPrice
            // 
            this.lblSpotPrice.AutoSize = true;
            this.lblSpotPrice.Location = new System.Drawing.Point(27, 302);
            this.lblSpotPrice.Name = "lblSpotPrice";
            this.lblSpotPrice.Size = new System.Drawing.Size(31, 13);
            this.lblSpotPrice.TabIndex = 5;
            this.lblSpotPrice.Text = "Price";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(27, 332);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(67, 13);
            this.lblTime.TabIndex = 7;
            this.lblTime.Text = "Current Time";
            // 
            // txtTradeName
            // 
            this.txtTradeName.Location = new System.Drawing.Point(143, 273);
            this.txtTradeName.Name = "txtTradeName";
            this.txtTradeName.Size = new System.Drawing.Size(176, 20);
            this.txtTradeName.TabIndex = 8;
            // 
            // txtSpotPrice
            // 
            this.txtSpotPrice.Location = new System.Drawing.Point(143, 302);
            this.txtSpotPrice.Name = "txtSpotPrice";
            this.txtSpotPrice.Size = new System.Drawing.Size(176, 20);
            this.txtSpotPrice.TabIndex = 9;
            // 
            // txtVolatility
            // 
            this.txtVolatility.Location = new System.Drawing.Point(143, 358);
            this.txtVolatility.Name = "txtVolatility";
            this.txtVolatility.Size = new System.Drawing.Size(176, 20);
            this.txtVolatility.TabIndex = 12;
            // 
            // txtRiskFreeRate
            // 
            this.txtRiskFreeRate.Location = new System.Drawing.Point(144, 392);
            this.txtRiskFreeRate.Name = "txtRiskFreeRate";
            this.txtRiskFreeRate.Size = new System.Drawing.Size(175, 20);
            this.txtRiskFreeRate.TabIndex = 13;
            // 
            // lblVoltality
            // 
            this.lblVoltality.AutoSize = true;
            this.lblVoltality.Location = new System.Drawing.Point(29, 364);
            this.lblVoltality.Name = "lblVoltality";
            this.lblVoltality.Size = new System.Drawing.Size(45, 13);
            this.lblVoltality.TabIndex = 14;
            this.lblVoltality.Text = "Volatility";
            // 
            // lblRiskFreeRate
            // 
            this.lblRiskFreeRate.AutoSize = true;
            this.lblRiskFreeRate.Location = new System.Drawing.Point(29, 398);
            this.lblRiskFreeRate.Name = "lblRiskFreeRate";
            this.lblRiskFreeRate.Size = new System.Drawing.Size(78, 13);
            this.lblRiskFreeRate.TabIndex = 15;
            this.lblRiskFreeRate.Text = "Risk Free Rate";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(146, 332);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(173, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(31, 441);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(111, 23);
            this.btnCalculate.TabIndex = 17;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(380, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Result Price";
            // 
            // txtCalculatedPrice
            // 
            this.txtCalculatedPrice.Enabled = false;
            this.txtCalculatedPrice.Location = new System.Drawing.Point(477, 275);
            this.txtCalculatedPrice.Name = "txtCalculatedPrice";
            this.txtCalculatedPrice.Size = new System.Drawing.Size(175, 20);
            this.txtCalculatedPrice.TabIndex = 19;
            // 
            // txtZAR
            // 
            this.txtZAR.Enabled = false;
            this.txtZAR.Location = new System.Drawing.Point(479, 326);
            this.txtZAR.Name = "txtZAR";
            this.txtZAR.Size = new System.Drawing.Size(100, 20);
            this.txtZAR.TabIndex = 20;
            // 
            // txtCHF
            // 
            this.txtCHF.Enabled = false;
            this.txtCHF.Location = new System.Drawing.Point(479, 354);
            this.txtCHF.Name = "txtCHF";
            this.txtCHF.Size = new System.Drawing.Size(100, 20);
            this.txtCHF.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "ZAR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(378, 360);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "CHF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(378, 308);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Agreegrate Value";
            // 
            // txtAgreegate
            // 
            this.txtAgreegate.Enabled = false;
            this.txtAgreegate.Location = new System.Drawing.Point(478, 301);
            this.txtAgreegate.Name = "txtAgreegate";
            this.txtAgreegate.Size = new System.Drawing.Size(174, 20);
            this.txtAgreegate.TabIndex = 25;
            // 
            // TradeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(879, 522);
            this.Controls.Add(this.txtAgreegate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCHF);
            this.Controls.Add(this.txtZAR);
            this.Controls.Add(this.txtCalculatedPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblRiskFreeRate);
            this.Controls.Add(this.lblVoltality);
            this.Controls.Add(this.txtRiskFreeRate);
            this.Controls.Add(this.txtVolatility);
            this.Controls.Add(this.txtSpotPrice);
            this.Controls.Add(this.txtTradeName);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblSpotPrice);
            this.Controls.Add(this.lblName);
            this.Controls.Add(btnFetch);
            this.Controls.Add(this.TradeGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReadFile);
            this.Name = "TradeForm";
            this.Text = "Trade Calculation";
            ((System.ComponentModel.ISupportInitialize)(this.TradeGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView TradeGridView;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSpotPrice;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox txtTradeName;
        private System.Windows.Forms.TextBox txtSpotPrice;
        private System.Windows.Forms.TextBox txtVolatility;
        private System.Windows.Forms.TextBox txtRiskFreeRate;
        private System.Windows.Forms.Label lblVoltality;
        private System.Windows.Forms.Label lblRiskFreeRate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCalculatedPrice;
        private System.Windows.Forms.TextBox txtZAR;
        private System.Windows.Forms.TextBox txtCHF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAgreegate;
    }
}

